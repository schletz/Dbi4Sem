#!/bin/bash

sqlplus system/oracle@//localhost/XEPDB1 @GRIESMAYER_CREATE_USER.sql
sqlplus griesmayer/oracle@//localhost/XEPDB1 @GRIESMAYER_CREATE_TABLES.plsql
sqlplus griesmayer/oracle@//localhost/XEPDB1 @GRIESMAYER_CREATE_TABLES.sql
sqlplus system/oracle@//localhost/XEPDB1 @GRIESMAYER_RIGHTS.sql

for FILE_NAME in `ls ../data/FACT_SALES_GRIESMAYER_*.csv`
do
   export BASE_NAME=`basename $FILE_NAME`
   export JUST_NAME=`echo $BASE_NAME | sed -e 's/\..*//'`
   echo $FILE_NAME
   echo $BASE_NAME
   echo $JUST_NAME

   sed -e 's/"//g' $FILE_NAME | sed -e 's/ ;/;/' | sed -e 's/,/./g' | dos2unix >../data/FACT_SALES_GRIESMAYER.csv 

   if [ `wc -l ../data/FACT_SALES_GRIESMAYER.csv | sed -e 's/ .*//'` -lt 20000 ]
   then
      >&2 echo Missing data in file $FILE_NAME.
      >&2 echo Only `wc -l ../data/FACT_SALES_GRIESMAYER.csv | sed -e 's/ .*//'` lines.
      exit 16
   fi

   sqlldr griesmayer/oracle@//localhost/XEPDB1 data=../data/FACT_SALES_GRIESMAYER.csv control=griesmayer_sales_staging.ldr log=../log/$JUST_NAME.log bad=../log/$JUST_NAME.bad errors=20

   if [ $? -ne 0 ]
   then
      >&2 echo Wrong data in file $FILE_NAME.
      >&2 echo Check log ../log/`echo $BASE_NAME | sed -e 's/\..*//'`.log.
      exit 17
   fi

   sqlplus griesmayer/oracle@//localhost/XEPDB1 <<!
      INSERT INTO SALES.FACT_GRIESMAYER_SALES
      SELECT SALES_DATE,
             SALES_TIME,
             SALES_CHANNEL,
             PRODUCT_ID,
             CUSTOMER_ID,
             sum(PIECES) as PIECES,
             sum(REVENUE) as REVENUE,
             sum(DISCOUNT) as DISCOUNT,
             sum(TAX) as TAX
      FROM   SALES.FACT_GRIESMAYER_SALES_STAGING
      GROUP BY SALES_DATE, SALES_TIME, SALES_CHANNEL, PRODUCT_ID, CUSTOMER_ID;
      exit;
!
done

