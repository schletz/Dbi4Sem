#!/bin/bash

sqlplus system/oracle@//localhost/XEPDB1 @GRIESMAYER_CREATE_USER.sql
sqlplus griesmayer/oracle@//localhost/XEPDB1 @GRIESMAYER_CREATE_TABLES.plsql
sqlplus griesmayer/oracle@//localhost/XEPDB1 @GRIESMAYER_CREATE_TABLES.sql
sqlplus system/oracle@//localhost/XEPDB1 @GRIESMAYER_RIGHTS.sql

sed -e 's/"//g' ../data/FACT_SALES_GRIESMAYER_201901.csv | sed -e 's/ ;/;/' | sed -e 's/,/./g' | dos2unix >../data/FACT_SALES_GRIESMAYER.csv 
sqlldr griesmayer/oracle@//localhost/XEPDB1 data=../data/FACT_SALES_GRIESMAYER.csv control=griesmayer_sales_staging.ldr log=../log/FACT_SALES_GRIESMAYER_201901.log bad=../log/FACT_SALES_GRIESMAYER_201901.bad errors=20
