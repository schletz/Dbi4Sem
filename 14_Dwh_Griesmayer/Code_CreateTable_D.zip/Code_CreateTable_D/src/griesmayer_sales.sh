#!/bin/bash

sqlplus system/oracle@//localhost/XEPDB1 @GRIESMAYER_CREATE_USER.sql
sqlplus system/oracle@//localhost/XEPDB1 @GRIESMAYER_CREATE_TABLES.plsql
sqlplus system/oracle@//localhost/XEPDB1 @GRIESMAYER_CREATE_TABLES.sql
